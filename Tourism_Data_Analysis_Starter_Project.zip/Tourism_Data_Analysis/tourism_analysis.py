"""
Tourism Data Analysis and Visualization
Run: python tourism_analysis.py
Note: The included CSV is sample/demo data for learning. Replace it with verified data
before using results in a formal report.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "dataset" / "tourism_data.csv"
OUTPUT_DIR = ROOT / "visualizations"
OUTPUT_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA_FILE)

print("\n--- TOURISM DATA: FIRST 5 ROWS ---")
print(df.head().to_string(index=False))
print("\n--- DATASET SHAPE ---")
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")
print("\n--- DATA TYPES AND MISSING VALUES ---")
print(df.info())
print(df.isnull().sum())
print("\n--- SUMMARY STATISTICS ---")
print(df.describe(numeric_only=True).round(2))
print("\n--- TOTAL VISITORS BY YEAR ---")
print(df.groupby("Year")["Visitors"].sum().to_string())
print("\n--- TOP DESTINATIONS BY TOTAL VISITORS ---")
print(df.groupby("Destination")["Visitors"].sum().sort_values(ascending=False).to_string())
print("\n--- TOTAL TOURISM REVENUE BY STATE (Lakh INR) ---")
print(df.groupby("State")["Tourism_Revenue_Lakh_INR"].sum().sort_values(ascending=False).to_string())

# 1. Total visitors by year
year_visitors = df.groupby("Year", as_index=False)["Visitors"].sum()
plt.figure(figsize=(8, 5))
plt.plot(year_visitors["Year"], year_visitors["Visitors"], marker="o")
plt.title("Total Tourist Visits by Year")
plt.xlabel("Year")
plt.ylabel("Number of Visitors")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "visitors_by_year.png", dpi=150)
plt.close()

# 2. Top destinations by visitors
top_destinations = df.groupby("Destination")["Visitors"].sum().sort_values(ascending=True)
plt.figure(figsize=(8, 5))
top_destinations.plot(kind="barh")
plt.title("Total Visitors by Destination")
plt.xlabel("Number of Visitors")
plt.ylabel("Destination")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "top_destinations.png", dpi=150)
plt.close()

# 3. Tourism revenue by state
state_revenue = df.groupby("State")["Tourism_Revenue_Lakh_INR"].sum().sort_values(ascending=False)
plt.figure(figsize=(8, 5))
state_revenue.plot(kind="bar")
plt.title("Tourism Revenue by State")
plt.xlabel("State")
plt.ylabel("Revenue (Lakh INR)")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "revenue_by_state.png", dpi=150)
plt.close()

# 4. Visitors by destination and year
pivot = df.pivot_table(index="Destination", columns="Year", values="Visitors", aggfunc="sum")
ax = pivot.plot(kind="bar", figsize=(10, 6))
ax.set_title("Destination Visitor Comparison by Year")
ax.set_xlabel("Destination")
ax.set_ylabel("Number of Visitors")
plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "destination_year_comparison.png", dpi=150)
plt.close()

print(f"\nCharts saved in: {OUTPUT_DIR}")
print("Analysis complete. Remember: the included data is illustrative sample data.")
