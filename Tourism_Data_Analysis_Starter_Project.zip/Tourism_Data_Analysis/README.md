# Tourism Data Analysis and Visualization

## Objective
Analyze tourism visits, popular destinations, tourism revenue, and visitor trends using Python, Pandas, and Matplotlib.

## Project structure
- `dataset/tourism_data.csv` — illustrative sample dataset
- `tourism_analysis.py` — analysis and chart-generation script
- `visualizations/` — charts are saved here when the script runs
- `notebook/` — optional Jupyter notebook work
- `dashboard/` — optional dashboard extension
- `report/` — report and findings

## Setup
1. Install Python 3.10 or newer.
2. Open this folder in VS Code.
3. Open the VS Code terminal in this folder.
4. Install the required packages:
   ```bash
   python -m pip install pandas matplotlib
   ```
5. Run:
   ```bash
   python tourism_analysis.py
   ```

If `python` is not recognized on Windows, try `py -m pip install pandas matplotlib` and `py tourism_analysis.py`.

## Questions this starter project explores
1. How do total visitor numbers change by year?
2. Which destination has the most visits in the sample?
3. Which state has the highest total tourism revenue?
4. How do destination visitor counts compare across years?
5. Are there missing values or unusual values to check?

## Important data note
The included rows are made-up illustrative sample data for demonstrating the workflow. They are **not official tourism statistics**. Replace them with a reliable, cited dataset before presenting real-world conclusions. Keep the original downloaded data unchanged and document cleaning decisions.

## Suggested extensions
- Add a Streamlit dashboard with year/state filters.
- Add season/month data to analyze seasonal tourism.
- Compare domestic and international visitors if the dataset contains those fields.
- Add a README section with data source, limitations, and findings.
